import React from "react"

export default () => <div style={{display: 'flex', justifyContent: 'center', margin: '.5rem,'}}>
    <div className="lds-hourglass" />
    </div>